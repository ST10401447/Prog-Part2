﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_PART2
{
    public class Ingredient
    {
        //Properties of ingredients
        private string name;
        private double measurement;
        private string unit;
        private double calories;
        private string foodGroup;

        public Ingredient(string name, double measurement, string unit, double calories, string foodGroup)
        {
            Name = name;
            Measurement = measurement;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
            
        }

        public string Name
        { 
            get { return name; }
            set { name = value; }
        }
        public double Measurement
        { 
            get { return measurement; }
            set { measurement = value; }
        }
        public string Unit 
        { 
            get { return unit; }
            set { unit = value; }
        }
        public double Calories 
        { 
            get { return calories; } 
            set { calories = value; }
        }
        public string FoodGroup 
        { 
            get { return foodGroup; } 
            set { foodGroup = value; }
        }

       
    }
}
