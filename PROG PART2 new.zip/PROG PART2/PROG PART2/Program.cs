﻿using Microsoft.Win32.SafeHandles;
using PROG_PART2;
using System.Transactions;

public class Program
{
    private static void Main(string[] args)
    {
        //Array list for the recipe
        List<Recipe> recipes = new List<Recipe>();
        List<String> recipeName = new List<String>();

        try
        {
            Console.Write("Would like to enter a recipe: ");
            string choice = Console.ReadLine();
            int count = 0;
            while (choice == "Y")
            {
                recipes.Add(new Recipe());

                Console.WriteLine("Enter the name for of the recipe: ");


                recipes[count].Name = Console.ReadLine();

                //Asking the user to insert ingredients inputs
                Console.WriteLine("Please enter the number  of ingredients");
                int noOfIngredients = int.Parse(Console.ReadLine());
                List<Ingredient> ingredients = new List<Ingredient>();
                for (int i = 0; i < noOfIngredients; i++)
                {
                     
                    Console.WriteLine("Enter the name for the ingredient :");
                    string name = Console.ReadLine();

                    Console.WriteLine("Enter the measurement of the ingredient : ");
                    double measure = double.Parse(Console.ReadLine());

                    Console.WriteLine("Enter the unit of the ingredient : ");
                    string unit = Console.ReadLine();

                    Console.WriteLine("Enter the number  of calories for the ingredient : ");
                    double calories = double.Parse(Console.ReadLine());

                    Console.WriteLine("Enter the food group type for the ingredient : ");
                    string foodGroup = Console.ReadLine();

                    ingredients.Add(new Ingredient(name,measure,unit,calories,foodGroup));
                }
                recipes[count].Ingredients = ingredients;

                //Asking the user the steps inputs
                Console.WriteLine("Enter the number of steps : ");
                int noOfSteps = int.Parse(Console.ReadLine());

                List<Step> steps = new List<Step> ();
                for (int j = 0; j < noOfSteps; j++)
                {
                    
                    Console.WriteLine("Enter the steps for the recipe : ");
                    string instruction = Console.ReadLine();
                    steps.Add(new Step(instruction));
                }

                recipes[count].Steps = steps;
                Console.Write("Would like to enter a recipe: ");
                choice = Console.ReadLine();
                count++;

            }
            bool isContinue = true;
            while (isContinue)
            {
                Console.WriteLine("Please choose a recipe");

                for (int i = 0; i < recipes.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {recipes[i].Name}");
                }
                int selection = int.Parse(Console.ReadLine());

                //Displaying the menu on how to dispaly the scale
                Console.WriteLine("***********Menu*************\n" +
                                  "1. View recipe at original scale\n" +
                                  "2. View recipe at double scale\n" +
                                  "3. View recipe at triple scale\n" +
                                  "4. View recipe at half scale\n ");
                int option = int.Parse(Console.ReadLine());

                while (option != 5 && option != 6)
                {
                    switch (option)
                    {
                        case 1:
                            Console.WriteLine($"************ Recipe Name: {recipes[selection - 1].Name}***********");
                            recipes[selection - 1].Display(1);
                            break;
                        case 2:
                            Console.WriteLine($"************ Recipe Name: {recipes[selection - 1].Name}***********");
                            recipes[selection - 1].Display(2);
                            break;
                        case 3:
                            Console.WriteLine($"************ Recipe Name: {recipes[selection - 1].Name}***********");
                            recipes[selection - 1].Display(3);
                            break;
                        case 4:
                            Console.WriteLine($"************ Recipe Name: {recipes[selection - 1].Name}***********");
                            recipes[selection - 1].Display(0.5);
                            break;
                        default:
                            option = 5;
                            break;
                    }

                    Console.WriteLine("***********Menu*************\n" +
                                  "1. View recipe at original scale\n" +
                                  "2. View recipe at double scale\n" +
                                  "3. View recipe at triple scale\n" +
                                  "4. View recipe at half scale\n" +
                                  "5. View different Recipe\n" +
                                  "6. Exit\n");
                    option = int.Parse(Console.ReadLine());
                }
                if (option == 5)
                {
                    isContinue = true;
                }
                else if (option == 6)
                {
                    isContinue = false;
                }
            }
            Console.WriteLine("Thank you for using the system!!!!!!!!!!!!!!!!!!!!!!");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}