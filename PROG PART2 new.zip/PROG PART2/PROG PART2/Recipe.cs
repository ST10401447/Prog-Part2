﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_PART2
{
    public delegate string CaloriesWarning(double calories);
    public class Recipe
    {
        //properties of the recipe
        private string name;
        private List<Ingredient> ingredients;
        private List<Step> steps;
        
        public string Name 
        {
            get { return name; } 
            set { name = value; } }
        public List<Ingredient> Ingredients 
        { 
            get {  return ingredients; } 
            set {  ingredients = value; } }
        public List<Step> Steps 
        { 
            get {  return steps; } 
            set { steps = value; }
        }

        
        //A method to display the recipe
        public void Display(double scale)
        {
            CaloriesWarning caloriesWarning = calories;
            Console.WriteLine("************* Ingredients of recipe **************** ");

            double caloriesNo = 0;

            for (int i = 0; i < ingredients.Count; i++)
            {
                //Displaying  the details of the ingredients of the recipe
                Console.WriteLine($"{i+1}. {ingredients[i].Name} {ingredients[i].Measurement*scale} \n" +
                $"{ingredients[i].Unit}  Food group: {ingredients[i].FoodGroup} \n" +
                $"Calories: {ingredients[i].Calories*scale}");

                caloriesNo= caloriesNo + ingredients[i].Calories*scale;
            }
            //Displaying number of calories
            Console.WriteLine($"The total number of calories is {caloriesNo} ");
            Console.WriteLine($"{caloriesWarning.Invoke(caloriesNo)}");

            //Displaying the steps of the recipe
            Console.WriteLine("Steps of the recipe : ");
            for(int j = 0;j < steps.Count; j++)
            {
                Console.WriteLine($"{j+1}.{steps[j].Instruction} ");
            }
        }
        //A method used to warn the user if calories are above 300
        public string calories(double caloriesNo)
        {
            string warningMessage = "";
            if(caloriesNo > 300)
            {
                warningMessage = "Warning! Calories are more than 300!";
            }
            return warningMessage;
        }

    }
}
