﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_PART2
{
    public class Step
    {
        //Declaration of properties of the steps

        private string instruction;

        public Step(string instruction)
        {
            this.instruction = instruction;
        }

        public  string Instruction 
        {  
            get { return instruction; } 
            set {  instruction = value; }
        }
    }
}
