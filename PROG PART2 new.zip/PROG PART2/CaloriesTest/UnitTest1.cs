namespace CaloriesTest
{
    using PROG_PART2;
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            //Unit test for calories
            Recipe recipe = new Recipe();
            double calories = 400;
            string expected = "Warning! Calories are more than 300!";

            string actual = recipe.calories(calories);

            Assert.AreEqual(expected, actual);
        }
    }
}